caffeine
===============================================================================


Run this to prevent your PC screen from locking.  It does this by simulating
that you've pressed the right context-menu key once every 59 seconds.

Double-click the icon to temporarily disable Caffeine, and permit your screen
to lock.

Under Win98:      a key down and then a key up event is simulated
Under Win2000/XP: a key up event is simulated

The additional event is required under Windows 98, otherwise the screen will
still lock.


Command-line options:

caffeine.exe -startoff		Application starts inactive
caffeine.exe -exitafter:xx	Application will terminate after xx minutes
caffeine.exe -activefor:xx	Application will become inactive after
				xx minutes
caffeine.exe -appexit		Terminates current running instance of
				application
caffeine.exe -appon		Makes the current running instance of the
				application active
caffeine.exe -appoff		Makes the current running instance of the
				application inactive
caffeine.exe xx                 xx is a number which sets the number of seconds
                                between simulated keypresses. This must be the
                                first text on the commandline

-------------------------------------------------------------------------------
Copyright Tom Revell, tom.revell@zhornsoftware.co.uk
Zhorn Software, http://www.zhornsoftware.co.uk/